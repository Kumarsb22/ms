package com.example.msapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
